console.log(' ');
console.log(' ');
console.log(' ');
console.log(' ');
console.log(' ');
console.log(' ');
console.log(' ');
console.log(' ');
console.log('####################################################');
console.log('##                                                ##');
console.log('##   BAMF created by BOC Business Solutions LLC   ##');
console.log('##                                                ##');
console.log('####################################################');
console.log('Starting BAMF services...');
console.log('Defining variable inputs for nodejs..');

var listenPortHttp = 80;
var url  = require('url');
var express = require('express');
var http = require('http');
var path = require('path');
var app = express();
var server = http.createServer(app);
var fs = require('fs');

console.log('Starting nodejs web server...');

app.use(express.static(path.join(__dirname, '/web')));
app.engine('.html', require('ejs').__express);
app.set('views', __dirname + '/web');
app.set('view engine', 'html');

console.log('BAMF Directory: '+__dirname);
console.log('Res Render: '+app.get('/', function(req, res){res.render('home.html')}));
console.log('Views Directory: '+app.get('views'));
console.log('View Engine: '+app.get('view engine'));

app.get('/', function(req, res){
    res.render('home.html');
});

http.createServer(app).listen(listenPortHttp);

console.log('HTTP Web service listening on port '+listenPortHttp);
