# Steps to setup certificate from certbot: https://wiki.alpinelinux.org/wiki/Nginx_as_reverse_proxy_with_acme_(letsencrypt)#Automatic_generation_of_certificates

apk update
apk add nginx acme-client libressl
openssl dhparam -dsaparam -out /etc/nginx/dhparam.pem 4096
chmod +x acme-client