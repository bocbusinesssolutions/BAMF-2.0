Please copy the following PEM files to this location:

- cert.pem
- chain.pem
- fullchain.pem
- privatekey.pem