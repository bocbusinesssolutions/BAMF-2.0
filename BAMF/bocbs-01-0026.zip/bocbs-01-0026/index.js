console.log(' ');
console.log(' ');
console.log(' ');
console.log(' ');
console.log(' ');
console.log(' ');
console.log(' ');
console.log(' ');
console.log('####################################################');
console.log('##                                                ##');
console.log('##   BAMF created by BOC Business Solutions LLC   ##');
console.log('##                                                ##');
console.log('####################################################');
console.log('Starting BAMF services...');
console.log('Defining variable inputs for nodejs..');

var listenPortHttp = 80;
var listenPortHttps = 443;
var io   = require('socket.io');
var url  = require('url');
var express = require('express');
var http = require('http');
var https = require('https');
var path = require('path');
var app = express();
var server = http.createServer(app);
var socket = io.listen(server);
var fs = require('fs');
var forceSsl = require('express-force-ssl');
var key = fs.readFileSync('sslcert/bocbs.key');
var cert = fs.readFileSync( 'sslcert/bocbs.crt' );
//var ca = fs.readFileSync( 'encryption/intermediate.crt' );
var options = {
  key: key,
  cert: cert,
  //ca: ca
};


console.log('Starting nodejs web server...');

app.use(forceSsl);
app.use(express.static(path.join(__dirname, '/web')));
app.engine('.html', require('ejs').__express);
app.set('views', __dirname + '/web');
app.set('ssl', __dirname + '/sslcerts');
app.set('view engine', 'html');

console.log('BAMF Directory: '+__dirname);
console.log('Res Render: '+app.get('/', function(req, res){res.render('home.html')}));
console.log('Views Directory: '+app.get('views'));
console.log('SSL Directory: '+app.get('ssl'));
console.log('View Engine: '+app.get('view engine'));

app.get('/', function(req, res){
    res.render('home.html');
});

//app.listen(listenPort);
http.createServer(app).listen(listenPortHttp);
https.createServer(options, app).listen(listenPortHttps);

console.log('HTTP Web service listening on port '+listenPortHttp);
console.log('HTTPS Web service listening on port '+listenPortHttps);
