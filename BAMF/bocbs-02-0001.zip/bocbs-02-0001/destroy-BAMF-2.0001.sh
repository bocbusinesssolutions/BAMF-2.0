echo Stopping BAMF 2.0001
docker stop bamf2.0001
echo Removing BAMF 2.0001 Container
docker rm bamf2.0001
docker ps
echo Removing BAMF 2.0001 Image
docker rmi bocbs-02-0001
docker rmi nginx
docker images
