docker build -t bocbs-02-0001 .
docker run --name bamf2.0001 -d -p 80:80 bocbs-02-0001